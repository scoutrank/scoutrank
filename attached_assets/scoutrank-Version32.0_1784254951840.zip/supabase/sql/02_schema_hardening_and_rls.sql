-- ScoutRank — schema hardening + correct RLS policies
-- Matches the REAL schema from "Scout Rank Bussines App Assignment 2026.docx":
--   profiles, athlete_details, posts, post_reactions, follows,
--   notifications, achievements, rankings
--
-- Paste this whole file into the Supabase SQL Editor and run it once.
-- Safe to re-run.

-- ════════════════════════════════════════════════════════════════
-- 1. NEW COLUMNS (additive, won't touch existing data)
-- ════════════════════════════════════════════════════════════════

alter table public.profiles
  add column if not exists username_changed boolean not null default false,
  add column if not exists account_status text not null default 'active',
  add column if not exists is_public boolean not null default true;
  -- account_status: 'active' | 'suspended' | 'banned'
  -- is_public: foundation for the privacy settings page; defaults open

alter table public.achievements
  add column if not exists status text not null default 'pending_review',
  add column if not exists points_value int not null default 0,
  add column if not exists ai_feedback text;
  -- status: 'pending_review' | 'ai_approved' | 'ai_rejected'
  --       | 'disputed' | 'admin_approved' | 'admin_rejected'

-- ════════════════════════════════════════════════════════════════
-- 2. NEW TABLE: disputes (athlete contests an AI rejection)
-- ════════════════════════════════════════════════════════════════

create table if not exists public.disputes (
  id uuid default gen_random_uuid() primary key,
  achievement_id uuid not null references public.achievements(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  explanation text not null,
  evidence_url text,
  ai_reason text,
  status text not null default 'pending', -- pending | approved | rejected | partial | info_requested
  admin_notes text,
  points_delta int not null default 0,
  resolved_by uuid references public.profiles(id),
  created_at timestamp default now(),
  resolved_at timestamp
);

-- ════════════════════════════════════════════════════════════════
-- 3. HELPER: is_admin() — avoids recursive RLS checks on profiles
-- ════════════════════════════════════════════════════════════════

create or replace function public.is_admin(uid uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = uid and role in ('admin', 'super_admin')
  );
$$;

-- ════════════════════════════════════════════════════════════════
-- 4. GUARD TRIGGER on profiles:
--    - blocks self-escalation of role / account_status
--    - enforces "username can change only once", server-side
-- ════════════════════════════════════════════════════════════════

create or replace function public.protect_profile_updates()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if (new.role is distinct from old.role
      or new.account_status is distinct from old.account_status)
     and not public.is_admin(auth.uid()) then
    raise exception 'Only an admin can change role or account_status';
  end if;

  if new.username is distinct from old.username then
    if old.username_changed then
      raise exception 'Username has already been changed once and cannot be changed again';
    end if;
    new.username_changed := true;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_protect_profile_updates on public.profiles;
create trigger trg_protect_profile_updates
  before update on public.profiles
  for each row
  execute function public.protect_profile_updates();

-- ════════════════════════════════════════════════════════════════
-- 5. ENABLE RLS on every table
-- ════════════════════════════════════════════════════════════════

alter table public.profiles        enable row level security;
alter table public.athlete_details enable row level security;
alter table public.posts           enable row level security;
alter table public.post_reactions  enable row level security;
alter table public.follows         enable row level security;
alter table public.notifications   enable row level security;
alter table public.achievements    enable row level security;
alter table public.rankings        enable row level security;
alter table public.disputes        enable row level security;

-- ════════════════════════════════════════════════════════════════
-- 6. POLICIES — drop+recreate so this file is safely re-runnable
-- ════════════════════════════════════════════════════════════════

-- profiles: public read, owner writes (role/account_status guarded by trigger above)
drop policy if exists "own profile only" on public.profiles;
drop policy if exists "profiles_select_public" on public.profiles;
drop policy if exists "profiles_modify_own" on public.profiles;
drop policy if exists "profiles_admin_modify_any" on public.profiles;

create policy "profiles_select_public" on public.profiles
  for select using (true);
create policy "profiles_modify_own" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "profiles_admin_modify_any" on public.profiles
  for update using (public.is_admin());

-- athlete_details: public read, owner writes
drop policy if exists "athlete_details_select_public" on public.athlete_details;
drop policy if exists "athlete_details_modify_own" on public.athlete_details;

create policy "athlete_details_select_public" on public.athlete_details
  for select using (true);
create policy "athlete_details_modify_own" on public.athlete_details
  for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

-- posts: public read, owner writes
drop policy if exists "own posts only" on public.posts;
drop policy if exists "posts_select_public" on public.posts;
drop policy if exists "posts_modify_own" on public.posts;

create policy "posts_select_public" on public.posts
  for select using (true);
create policy "posts_modify_own" on public.posts
  for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

-- post_reactions ("boost" / 💪): public read, owner inserts/removes their own boost
drop policy if exists "can boost" on public.post_reactions;
drop policy if exists "reactions_select_public" on public.post_reactions;
drop policy if exists "reactions_insert_own" on public.post_reactions;
drop policy if exists "reactions_delete_own" on public.post_reactions;

create policy "reactions_select_public" on public.post_reactions
  for select using (true);
create policy "reactions_insert_own" on public.post_reactions
  for insert with check (auth.uid() = profile_id);
create policy "reactions_delete_own" on public.post_reactions
  for delete using (auth.uid() = profile_id);

-- follows: public read (so follower/following counts work), owner manages own follow rows
drop policy if exists "follows_select_public" on public.follows;
drop policy if exists "follows_insert_own" on public.follows;
drop policy if exists "follows_delete_own" on public.follows;

create policy "follows_select_public" on public.follows
  for select using (true);
create policy "follows_insert_own" on public.follows
  for insert with check (auth.uid() = follower_id);
create policy "follows_delete_own" on public.follows
  for delete using (auth.uid() = follower_id);

-- notifications: private to the recipient; any signed-in user can create one
-- for someone else (e.g. "X followed you"); recipient can mark read/delete
drop policy if exists "own notifications" on public.notifications;
drop policy if exists "notifications_select_own" on public.notifications;
drop policy if exists "notifications_insert_authenticated" on public.notifications;
drop policy if exists "notifications_update_own" on public.notifications;
drop policy if exists "notifications_delete_own" on public.notifications;

create policy "notifications_select_own" on public.notifications
  for select using (auth.uid() = user_id);
create policy "notifications_insert_authenticated" on public.notifications
  for insert to authenticated with check (true);
create policy "notifications_update_own" on public.notifications
  for update using (auth.uid() = user_id);
create policy "notifications_delete_own" on public.notifications
  for delete using (auth.uid() = user_id);

-- achievements: public read, owner inserts/deletes own, owner OR admin can update
-- (admin needs update access to approve/reject submissions)
drop policy if exists "achievements_select_public" on public.achievements;
drop policy if exists "achievements_insert_own" on public.achievements;
drop policy if exists "achievements_update_own_or_admin" on public.achievements;
drop policy if exists "achievements_delete_own" on public.achievements;

create policy "achievements_select_public" on public.achievements
  for select using (true);
create policy "achievements_insert_own" on public.achievements
  for insert with check (auth.uid() = profile_id);
create policy "achievements_update_own_or_admin" on public.achievements
  for update using (auth.uid() = profile_id or public.is_admin());
create policy "achievements_delete_own" on public.achievements
  for delete using (auth.uid() = profile_id);

-- rankings: public read; only admin can write directly (score changes go
-- through the review/dispute flow, not a self-service edit)
drop policy if exists "rankings_select_public" on public.rankings;
drop policy if exists "rankings_admin_write" on public.rankings;

create policy "rankings_select_public" on public.rankings
  for select using (true);
create policy "rankings_admin_write" on public.rankings
  for all using (public.is_admin()) with check (public.is_admin());

-- disputes: athlete sees/creates their own, only admin can resolve (update)
drop policy if exists "disputes_select_own_or_admin" on public.disputes;
drop policy if exists "disputes_insert_own" on public.disputes;
drop policy if exists "disputes_update_admin_only" on public.disputes;

create policy "disputes_select_own_or_admin" on public.disputes
  for select using (auth.uid() = profile_id or public.is_admin());
create policy "disputes_insert_own" on public.disputes
  for insert with check (auth.uid() = profile_id);
create policy "disputes_update_admin_only" on public.disputes
  for update using (public.is_admin());

-- ════════════════════════════════════════════════════════════════
-- 7. INDEXES for the queries the app actually runs
-- ════════════════════════════════════════════════════════════════

create index if not exists idx_posts_profile_id on public.posts(profile_id);
create index if not exists idx_posts_created_at on public.posts(created_at desc);
create index if not exists idx_reactions_post_id on public.post_reactions(post_id);
create index if not exists idx_follows_follower on public.follows(follower_id);
create index if not exists idx_follows_following on public.follows(following_id);
create index if not exists idx_notifications_user on public.notifications(user_id, created_at desc);
create index if not exists idx_achievements_profile on public.achievements(profile_id);
create index if not exists idx_achievements_status on public.achievements(status);
create index if not exists idx_rankings_sport_score on public.rankings(sport, rank_score desc);
create index if not exists idx_disputes_achievement on public.disputes(achievement_id);

-- ════════════════════════════════════════════════════════════════
-- ScoutRank — hotfix for the signup trigger (public.handle_new_user)
-- Run this in the Supabase SQL Editor. Safe to re-run.
--
-- Fixes:
--   1. Removed "on conflict (profile_id)" on athlete_details — that clause
--      throws a hard Postgres error if profile_id isn't a unique/PK
--      constraint there, which rolls back the WHOLE signup transaction
--      (this was very likely why signup failed at the final step).
--   2. secondary_sports is sent from the signup form as a JSON array, not
--      a plain string — now parsed correctly into a comma-joined value.
--   3. age is computed from date_of_birth (what the form actually sends),
--      instead of expecting an "age" key that was never being sent.
--   4. The athlete_details insert is now wrapped in its own exception
--      handler — if it fails for any reason, the account is still created
--      (just without that row), instead of blocking signup entirely.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  base_username text := coalesce(meta->>'username', split_part(new.email, '@', 1));
  final_username text := base_username;
  attempt int := 0;
  dob date;
  computed_age int;
  secondary_sports_text text;
begin
  -- Compute age from date_of_birth, if present and parseable
  begin
    if meta->>'date_of_birth' is not null and meta->>'date_of_birth' <> '' then
      dob := (meta->>'date_of_birth')::date;
      computed_age := extract(year from age(current_date, dob))::int;
    end if;
  exception when others then
    computed_age := null;
  end;

  -- secondary_sports arrives as a JSON array, e.g. ["Athletics","Swimming"]
  select string_agg(value, ', ')
  into secondary_sports_text
  from jsonb_array_elements_text(
    case jsonb_typeof(meta->'secondary_sports')
      when 'array' then meta->'secondary_sports'
      else '[]'::jsonb
    end
  );

  loop
    begin
      insert into public.profiles (
        id, username, first_name, last_name, bio, age,
        country, state, city, role, created_at
      )
      values (
        new.id,
        final_username,
        coalesce(meta->>'first_name', ''),
        coalesce(meta->>'last_name', ''),
        '',
        computed_age,
        coalesce(meta->>'country', ''),
        coalesce(meta->>'state', ''),
        coalesce(meta->>'city', ''),
        coalesce(meta->>'role', 'athlete'),
        now()
      );
      exit;
    exception when unique_violation then
      attempt := attempt + 1;
      final_username := base_username || '_' || attempt::text;
      if attempt > 20 then
        raise exception 'Could not generate a unique username for user %', new.id;
      end if;
    end;
  end loop;

  -- athlete_details: isolated so a failure here can never block signup
  begin
    insert into public.athlete_details (profile_id, primary_sport, secondary_sports, club)
    values (
      new.id,
      coalesce(meta->>'primary_sport', ''),
      coalesce(secondary_sports_text, ''),
      coalesce(meta->>'current_club', '')
    );
  exception when others then
    raise warning 'handle_new_user: athlete_details insert failed for %: %', new.id, sqlerrm;
  end;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
