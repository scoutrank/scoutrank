import { supabase } from '@/lib/supabase';

export type MediaKind = 'photo' | 'video' | 'audio';

function extensionFromMime(mime: string, kind: MediaKind): string {
  if (mime.includes('png')) return 'png';
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('gif')) return 'gif';
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('quicktime')) return 'mov';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('mpeg') || mime.includes('mp3')) return 'mp3';
  if (mime.includes('aac')) return 'aac';
  if (mime.includes('ogg')) return 'ogg';
  if (mime.includes('wav')) return 'wav';
  // No reliable mime (e.g. some recorders report '' for certain
  // codecs) — fall back to a sensible default per kind.
  return kind === 'photo' ? 'jpg' : 'webm';
}

export function kindFromMime(mime: string): MediaKind {
  if (mime.startsWith('image/')) return 'photo';
  if (mime.startsWith('video/')) return 'video';
  return 'audio';
}

// Uploads a Blob/File to the post-media bucket under the uploader's own
// profile-id folder (required for the post_media_insert_own_folder
// Storage policy from SQL #30 to allow the write), then returns the
// real public URL. This replaces converting media to a giant base64
// string — posts.media_url now points at a real file.
export async function uploadMediaBlob(blob: Blob, profileId: string, kind: MediaKind): Promise<string> {
  const ext = extensionFromMime(blob.type, kind);
  const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const path = `${profileId}/${filename}`;


  const { error } = await supabase.storage.from('post-media').upload(path, blob, {
    contentType: blob.type || undefined,
    upsert: false,
  });

  if (error) {
    console.error('[mediaStorage] upload failed:', error.message);
    throw new Error(`Failed to upload media: ${error.message}`);
  }

  const { data } = supabase.storage.from('post-media').getPublicUrl(path);
  return data.publicUrl;
}
