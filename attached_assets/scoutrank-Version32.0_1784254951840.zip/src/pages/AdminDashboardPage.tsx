import { useState, useEffect } from 'react';
import { shortDate } from '@/utils/time';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, fullName, displayScoutRank } from '@/lib/supabase';
import type { Profile } from '@/lib/supabase';
import { Button } from '@/components/ui/Button';
import { Logo } from '@/components/ui/Logo';
import {
  Users, Flag, AlertCircle, Shield, BarChart3, Building2,
  Settings, Search, TrendingUp, CheckCircle, XCircle, Eye,
  Ban, AlertTriangle, MessageCircle, Clock,
  Trash2, Lock, Unlock, Inbox, Trophy, Loader2,
} from 'lucide-react';

type AdminTab = 'analytics' | 'users' | 'posts' | 'reports' | 'disputes' | 'verification' | 'flagged' | 'rankings' | 'organisations' | 'org_requests' | 'pending_stats' | 'settings';

const adminTabs: { id: AdminTab; label: string; icon: typeof Users }[] = [
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'posts', label: 'Posts', icon: MessageCircle },
  { id: 'reports', label: 'Reports', icon: Flag },
  { id: 'disputes', label: 'Disputes', icon: AlertCircle },
  { id: 'verification', label: 'Verification', icon: Shield },
  { id: 'flagged', label: 'AI Flagged', icon: AlertTriangle },
  { id: 'rankings', label: 'Rankings', icon: TrendingUp },
  { id: 'organisations', label: 'Organisations', icon: Building2 },
  { id: 'org_requests',         label: 'Org Requests',         icon: Inbox },
  { id: 'pending_stats',        label: 'Pending Stats',        icon: BarChart3 },
  { id: 'reports' as AdminTab, label: 'Reports',              icon: Flag },
  { id: 'settings',             label: 'Settings',             icon: Settings },
];

interface AdminDispute {
  id: string;
  userId: string;
  profileName: string;
  targetType: string;
  targetDesc: string;
  aiReason: string;
  athleteExplanation: string;
  evidenceCount: number;
  status: 'open' | 'under_review' | 'resolved';
  priority: 'low' | 'medium' | 'high' | 'critical';
  created: string;
}

interface AdminVerification {
  id: string;
  userId: string;
  profileName: string;
  targetType: string;
  targetDesc: string;
  evidenceCount: number;
  status: 'pending' | 'approved' | 'rejected';
  submitted: string;
}

export default function AdminDashboardPage() {
  const { profile, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('analytics');
  const [searchQuery, setSearchQuery] = useState('');

  // ── Real data ──────────────────────────────────────────────────
  const [allUsers, setAllUsers] = useState<Profile[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [analytics, setAnalytics] = useState({
    totalUsers: 0, totalPosts: 0, totalOrgs: 0,
    pendingStats: 0, pendingVerifications: 0,
  });
  const [loadingAnalytics, setLoadingAnalytics] = useState(true);

  useEffect(() => {
    supabase.from('profiles').select('*').order('created_at', { ascending: false })
      .then(({ data }) => { setAllUsers((data as Profile[] | null) ?? []); setLoadingUsers(false); });

    Promise.all([
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('posts').select('id', { count: 'exact', head: true }),
      supabase.from('organisations').select('id', { count: 'exact', head: true }).eq('verified', true),
      supabase.from('athlete_stats').select('id', { count: 'exact', head: true }).eq('verification_status', 'pending'),
      supabase.from('verification_submissions').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    ]).then(([users, posts, orgs, pendingStats, pendingVer]) => {
      setAnalytics({
        totalUsers:           users.count ?? 0,
        totalPosts:           posts.count ?? 0,
        totalOrgs:            orgs.count ?? 0,
        pendingStats:         pendingStats.count ?? 0,
        pendingVerifications: pendingVer.count ?? 0,
      });
      setLoadingAnalytics(false);
    });
  }, []);

  const disputes: unknown[] = [];
  const verifications: unknown[] = [];
  const [userStatuses, setUserStatuses] = useState<Record<string, 'active' | 'suspended' | 'banned'>>({});;

  const updateAccountStatus = async (userId: string, status: 'active' | 'suspended' | 'banned') => {
    const { error } = await supabase
      .from('profiles')
      .update({ account_status: status })
      .eq('id', userId);
    if (error) {
      console.error(`[ADMIN] Failed to set status=${status} for user ${userId}:`, error.message);
      return false;
    }
    setUserStatuses(prev => ({ ...prev, [userId]: status }));
    return true;
  };

  const handleBanUser = (userId: string) => { updateAccountStatus(userId, 'banned'); };
  const handleSuspendUser = (userId: string) => { updateAccountStatus(userId, 'suspended'); };
  const handleUnbanUser = (userId: string) => { updateAccountStatus(userId, 'active'); };

  const handleDeleteUser = (userId: string, profileId: string) => {
    // Account deletion requires elevated server-side privileges (service_role key)
    // and cannot be done from a plain authenticated client. Stubbed until an
    // admin-delete RPC is created. Clicking this has no lasting effect.
    setUserStatuses(prev => { const n = { ...prev }; delete n[userId]; return n; });
    console.error('[ADMIN] deleteUser is not yet implemented — requires a server-side RPC.');
  };

  const handleApproveVerification = async (verId: string) => {
    const { error } = await supabase
      .from('coach_verifications')
      .update({ status: 'approved', reviewed_at: new Date().toISOString() })
      .eq('id', verId);
    if (error) { console.error('[ADMIN] Approve verification failed:', error.message); return; }
    setVerifications(prev => prev.map((v: Record<string, unknown>) => v.id === verId ? { ...v, status: 'approved' as const } : v));
  };

  const handleRejectVerification = async (verId: string) => {
    const { error } = await supabase
      .from('coach_verifications')
      .update({ status: 'rejected', reviewed_at: new Date().toISOString() })
      .eq('id', verId);
    if (error) { console.error('[ADMIN] Reject verification failed:', error.message); return; }
    setVerifications(prev => prev.map((v: Record<string, unknown>) => v.id === verId ? { ...v, status: 'rejected' as const } : v));
  };

  const handleApproveDispute = (disputeId: string) => {
    // TODO: write to DB via dispute resolution RPC (stale local-state only for now)
    setDisputes(prev => prev.map(d => d.id === disputeId ? { ...d, status: 'resolved' as const } : d));
  };

  const handleRejectDispute = (disputeId: string) => {
    setDisputes(prev => prev.map(d => d.id === disputeId ? { ...d, status: 'resolved' as const } : d));
  };

  const displayedUsers = allUsers.filter(u => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
  });

  const totalUsers = allUsers.length + 1; // +1 for admin
  const activeUsers = allUsers.filter(u => (userStatuses[u.id] || u.status) === 'active').length + 1;
  const bannedUsers = allUsers.filter(u => (userStatuses[u.id] || u.status) === 'banned').length;
  const suspendedUsers = allUsers.filter(u => (userStatuses[u.id] || u.status) === 'suspended').length;

  return (
    <div className="min-h-screen bg-sr-bg">
      {/* Header */}
      <div className="border-b border-sr-border bg-sr-surface/50">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo size="sm" />
            <span className="h-5 w-px bg-sr-border" />
            <span className="text-sm font-semibold text-sr-purple-light flex items-center gap-1.5">
              <Shield className="h-4 w-4" /> Admin Dashboard
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-sr-text-muted" />
              <input className="input-dark pl-9 py-1.5 text-xs w-56" placeholder="Search users, disputes..."
                value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
            </div>
            <span className="text-xs text-sr-text-muted">{profile ? fullName(profile) : ''} (Admin)</span>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-3.5rem)]">
        {/* Sidebar */}
        <aside className="w-56 border-r border-sr-border bg-sr-surface/30 overflow-y-auto flex-shrink-0 hidden md:block">
          <nav className="p-2 space-y-0.5">
            {adminTabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.id ? 'bg-sr-purple/10 text-sr-purple-light border border-sr-purple/20' : 'text-sr-text-muted hover:text-white hover:bg-sr-surface-light'
                }`}>
                <tab.icon className="h-4 w-4" />{tab.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile tabs */}
        <div className="md:hidden w-full overflow-x-auto border-b border-sr-border bg-sr-surface/30">
          <div className="flex p-2 gap-1">
            {adminTabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${activeTab === tab.id ? 'bg-sr-purple/10 text-sr-purple-light' : 'text-sr-text-muted'}`}>
                <tab.icon className="h-3.5 w-3.5" />{tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main */}
        <main className="flex-1 overflow-y-auto p-6">
                    {activeTab === 'analytics' && (
            <div>
              <h2 className="text-xl font-bold text-white mb-6">Platform Analytics</h2>
              {loadingAnalytics ? (
                <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 text-sr-purple animate-spin" /></div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {[
                      { label: 'Total Users',   value: analytics.totalUsers,   icon: Users,        color: 'from-sr-purple to-sr-blue' },
                      { label: 'Total Posts',   value: analytics.totalPosts,   icon: MessageCircle,color: 'from-green-400 to-emerald-500' },
                      { label: 'Verified Orgs', value: analytics.totalOrgs,    icon: Building2,    color: 'from-sr-blue to-cyan-400' },
                    ].map(s => (
                      <div key={s.label} className="card-premium p-5">
                        <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-3`}>
                          <s.icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="text-2xl font-bold text-white">{s.value}</div>
                        <div className="text-xs text-sr-text-muted">{s.label}</div>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {[
                      { label: 'Pending Stat Reviews',         value: analytics.pendingStats,         icon: BarChart3,    color: 'text-yellow-400',  to: '/admin/pending-stats' },
                      { label: 'Pending Verifications',        value: analytics.pendingVerifications,  icon: Shield,       color: 'text-sr-purple-light', to: '/admin/verification' },
                    ].map(s => (
                      <Link key={s.label} to={s.to} className="card-premium p-5 hover:border-sr-purple/30 transition-colors group flex items-center gap-3">
                        <s.icon className={`h-6 w-6 ${s.color}`} />
                        <div className="flex-1">
                          <div className="text-xl font-bold text-white">{s.value}</div>
                          <div className="text-xs text-sr-text-muted">{s.label}</div>
                        </div>
                        {s.value > 0 && <span className="h-2 w-2 rounded-full bg-yellow-400 flex-shrink-0" />}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

                    {activeTab === 'users' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Users ({allUsers.length})</h2>
                <input className="input-dark py-1.5 text-xs w-56 pl-3" placeholder="Search name or username..."
                  value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
              {loadingUsers ? (
                <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 text-sr-purple animate-spin" /></div>
              ) : (
                <div className="card-premium overflow-hidden">
                  <table className="w-full">
                    <thead><tr className="text-left text-xs text-sr-text-muted border-b border-sr-border">
                      <th className="p-3 pl-6">User</th><th className="p-3">Role</th><th className="p-3">Joined</th><th className="p-3">Score</th>
                    </tr></thead>
                    <tbody>
                      {allUsers
                        .filter(u => !searchQuery || fullName(u).toLowerCase().includes(searchQuery.toLowerCase()) || u.username.toLowerCase().includes(searchQuery.toLowerCase()))
                        .map(u => (
                          <tr key={u.id} className="border-b border-sr-border/50 hover:bg-sr-surface-light/50">
                            <td className="p-3 pl-6">
                              <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-lg overflow-hidden flex-shrink-0">
                                  {u.avatar_url
                                    ? <img src={u.avatar_url} alt="" className="h-full w-full object-cover" />
                                    : <div className="h-full w-full bg-gradient-to-br from-sr-purple/50 to-sr-blue/50 flex items-center justify-center text-xs font-bold text-white">{u.first_name?.[0]}{u.last_name?.[0]}</div>
                                  }
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-white">{fullName(u)}</p>
                                  <p className="text-xs text-sr-text-muted">@{u.username}</p>
                                </div>
                              </div>
                            </td>
                            <td className="p-3">
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                u.role === 'admin' || u.role === 'super_admin' ? 'bg-sr-purple/10 text-sr-purple-light' :
                                u.role === 'coach' ? 'bg-blue-500/10 text-blue-400' :
                                u.role === 'scout' ? 'bg-green-500/10 text-green-400' :
                                u.role === 'parent' ? 'bg-orange-500/10 text-orange-400' :
                                'bg-sr-surface text-sr-text-muted'
                              }`}>{u.role}</span>
                            </td>
                            <td className="p-3 text-xs text-sr-text-muted">{shortDate(u.created_at)}</td>
                            <td className="p-3 text-xs text-sr-silver">{displayScoutRank(u.scoutrank_score)}</td>
                          </tr>
                        ))
                      }
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'posts' && (
            <div><h2 className="text-xl font-bold text-white mb-6">Post Moderation</h2><div className="card-premium p-6"><p className="text-sm text-sr-text-muted">Review and moderate reported posts and content.</p></div></div>
          )}

          {activeTab === 'reports' && (
            <div><h2 className="text-xl font-bold text-white mb-6">Reports</h2><div className="card-premium p-12 text-center"><Flag className="h-12 w-12 mx-auto text-sr-text-muted mb-4" /><p className="text-sr-text-muted">No open reports to review.</p></div></div>
          )}

          {activeTab === 'organisations' && (
            <div>
              <h2 className="text-xl font-bold text-white mb-6">Organisation Registry</h2>
              <div className="card-premium p-8 text-center">
                <Building2 className="h-12 w-12 mx-auto text-sr-purple mb-4" />
                <p className="text-white font-semibold mb-2">Clubs, Schools &amp; Academies</p>
                <p className="text-sm text-sr-text-muted mb-4">
                  Add, edit and verify organisations. Verified organisations appear in autocomplete when coaches and scouts submit for verification.
                </p>
                <Link to="/admin/organisations">
                  <Button variant="brand" icon={<Building2 className="h-4 w-4" />}>Open Organisation Registry</Button>
                </Link>
              </div>
            </div>
          )}

          {activeTab === 'org_requests' && (
            <div>
              <h2 className="text-xl font-bold text-white mb-6">Organisation Requests</h2>
              <div className="card-premium p-8 text-center">
                <Inbox className="h-12 w-12 mx-auto text-sr-purple mb-4" />
                <p className="text-white font-semibold mb-2">User-Submitted Organisation Requests</p>
                <p className="text-sm text-sr-text-muted mb-4">
                  Review, approve or reject requests to add new clubs, schools and academies to the registry.
                </p>
                <Link to="/admin/organisation-requests">
                  <Button variant="brand" icon={<Inbox className="h-4 w-4" />}>Open Org Requests Queue</Button>
                </Link>
              </div>
            </div>
          )}

          {activeTab === 'pending_stats' && (
            <div>
              <h2 className="text-xl font-bold text-white mb-6">Pending Athlete Stats</h2>
              <div className="card-premium p-8 text-center">
                <BarChart3 className="h-12 w-12 mx-auto text-sr-purple mb-4" />
                <p className="text-white font-semibold mb-2">Stat Submission Review</p>
                <p className="text-sm text-sr-text-muted mb-4">Review, verify or reject athlete stat submissions. Approving triggers automatic score recalculation.</p>
                <Link to="/admin/pending-stats">
                  <Button variant="brand" icon={<BarChart3 className="h-4 w-4" />}>Open Pending Stats</Button>
                </Link>
              </div>
            </div>
          )}

          {activeTab === 'reports' && (
            <div>
              <h2 className="text-xl font-bold text-white mb-6">Reports</h2>
              <div className="card-premium p-8 text-center">
                <Flag className="h-12 w-12 mx-auto text-red-400 mb-4" />
                <p className="text-white font-semibold mb-2">User Reports</p>
                <p className="text-sm text-sr-text-muted mb-4">Review reports submitted by athletes for profiles, posts and messages.</p>
                <Link to="/admin/reports">
                  <Button variant="brand" icon={<Flag className="h-4 w-4" />}>Open Reports</Button>
                </Link>
              </div>
            </div>
          )}



          {activeTab === 'settings' && (
            <div><h2 className="text-xl font-bold text-white mb-6">Admin Settings</h2><div className="card-premium p-6"><p className="text-sm text-sr-silver">Platform configuration, admin role management, audit logs.</p></div></div>
          )}
        </main>
      </div>
    </div>
  );
}
