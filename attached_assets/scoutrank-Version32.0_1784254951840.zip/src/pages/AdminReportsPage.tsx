import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/Button';
import { timeAgo } from '@/utils/time';
import { Flag, Loader2, AlertCircle, ExternalLink, Check, X } from 'lucide-react';

interface ReportRow {
  id: string;
  reporter_id: string;
  reported_profile_id: string | null;
  reported_post_id: string | null;
  reason: string;
  details: string | null;
  status: 'pending' | 'reviewed' | 'dismissed' | 'actioned';
  created_at: string;
  reviewed_at: string | null;
  reporter?: { username: string; first_name: string; last_name: string };
  reported_profile?: { username: string; first_name: string; last_name: string } | null;
}

const STATUS_STYLES: Record<string, string> = {
  pending:   'text-yellow-400 bg-yellow-400/10 border-yellow-400/20',
  reviewed:  'text-blue-400  bg-blue-400/10  border-blue-400/20',
  dismissed: 'text-sr-text-muted bg-sr-surface border-sr-border',
  actioned:  'text-green-400  bg-green-400/10  border-green-400/20',
};

export default function AdminReportsPage() {
  const { isAdmin } = useAuth();
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [actioning, setActioning] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('pending');

  if (!isAdmin) {
    return <div className="flex items-center justify-center py-20 text-sr-text-muted">Admin access required.</div>;
  }

  const load = async () => {
    setIsLoading(true);
    setError('');
    let q = supabase
      .from('reports')
      .select(`
        id, reporter_id, reported_profile_id, reported_post_id,
        reason, details, status, created_at, reviewed_at,
        reporter:reporter_id(username, first_name, last_name),
        reported_profile:reported_profile_id(username, first_name, last_name)
      `)
      .order('created_at', { ascending: false })
      .limit(100);
    if (statusFilter !== 'all') q = q.eq('status', statusFilter);
    const { data, error: qErr } = await q;
    if (qErr) { setError(qErr.message); setIsLoading(false); return; }
    setReports((data as unknown as ReportRow[]) ?? []);
    setIsLoading(false);
  };

  useEffect(() => { load(); }, [statusFilter]);

  const updateStatus = async (id: string, newStatus: ReportRow['status']) => {
    setActioning(id);
    const { error: upErr } = await supabase.from('reports').update({
      status: newStatus,
      reviewed_at: new Date().toISOString(),
    }).eq('id', id);
    setActioning(null);
    if (upErr) { setError(upErr.message); return; }
    setReports(prev => prev.map(r => r.id === id ? { ...r, status: newStatus, reviewed_at: new Date().toISOString() } : r));
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <Flag className="h-7 w-7 text-red-400" />
        <h1 className="text-2xl font-bold text-white">Reports</h1>
        <span className="text-xs text-sr-text-muted bg-sr-surface border border-sr-border px-2 py-0.5 rounded-full">
          {reports.length} shown
        </span>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />{error}
        </div>
      )}

      {/* Status filter */}
      <div className="flex gap-2 mb-6">
        {['pending', 'reviewed', 'dismissed', 'actioned', 'all'].map(s => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`text-xs px-3 py-1.5 rounded-lg border capitalize transition-colors ${
              statusFilter === s ? 'border-sr-purple bg-sr-purple/10 text-white' : 'border-sr-border text-sr-text-muted hover:border-sr-purple/30'
            }`}>
            {s}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-16"><Loader2 className="h-8 w-8 text-sr-purple animate-spin" /></div>
      ) : reports.length === 0 ? (
        <div className="card-premium p-12 text-center">
          <Flag className="h-12 w-12 mx-auto text-sr-text-muted mb-4" />
          <p className="text-white font-semibold mb-1">No {statusFilter === 'all' ? '' : statusFilter} reports</p>
          <p className="text-sm text-sr-text-muted">Nothing to review right now.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reports.map(r => (
            <div key={r.id} className="card-premium p-5">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold uppercase ${STATUS_STYLES[r.status]}`}>
                      {r.status}
                    </span>
                    <span className="text-xs text-sr-text-muted">{timeAgo(r.created_at)}</span>
                  </div>
                  <p className="text-sm font-semibold text-white">{r.reason}</p>
                  {r.details && <p className="text-xs text-sr-text-muted mt-0.5">{r.details}</p>}
                </div>
                {r.status === 'pending' && (
                  <div className="flex gap-2 flex-shrink-0">
                    <Button variant="ghost" size="sm" disabled={actioning === r.id}
                      onClick={() => updateStatus(r.id, 'dismissed')}
                      icon={actioning === r.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}>
                      Dismiss
                    </Button>
                    <Button variant="brand" size="sm" disabled={actioning === r.id}
                      onClick={() => updateStatus(r.id, 'actioned')}
                      icon={actioning === r.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}>
                      Action
                    </Button>
                  </div>
                )}
              </div>
              <div className="grid sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <p className="text-sr-text-muted mb-0.5">Reported by</p>
                  {r.reporter ? (
                    <Link to={`/profile/${r.reporter.username}`} className="text-sr-silver hover:text-white transition-colors">
                      {r.reporter.first_name} {r.reporter.last_name} (@{r.reporter.username})
                    </Link>
                  ) : <span className="text-sr-text-muted">Unknown</span>}
                </div>
                {r.reported_profile && (
                  <div>
                    <p className="text-sr-text-muted mb-0.5">Reported profile</p>
                    <Link to={`/profile/${r.reported_profile.username}`} className="text-sr-silver hover:text-white transition-colors flex items-center gap-1">
                      {r.reported_profile.first_name} {r.reported_profile.last_name} (@{r.reported_profile.username})
                      <ExternalLink className="h-3 w-3" />
                    </Link>
                  </div>
                )}
                {r.reported_post_id && (
                  <div>
                    <p className="text-sr-text-muted mb-0.5">Reported post</p>
                    <Link to={`/post/${r.reported_post_id}`} className="text-sr-purple-light hover:text-white transition-colors flex items-center gap-1">
                      View post <ExternalLink className="h-3 w-3" />
                    </Link>
                  </div>
                )}
              </div>
              {r.reviewed_at && (
                <p className="text-[10px] text-sr-text-muted mt-2">Reviewed {timeAgo(r.reviewed_at)}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
