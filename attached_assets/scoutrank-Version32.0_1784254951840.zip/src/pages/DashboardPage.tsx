import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/Button';
import { supabase, fullName, displayScoutRank } from '@/lib/supabase';
import { TrendUpIcon, TrendDownIcon } from '@/components/icons';
import { getTrustMeta, TrustBadge } from '@/components/ui/TrustBadge';
import type { Profile, Post } from '@/lib/supabase';
import {
  BarChart3, TrendingUp, Award, FileText, Sparkles,
  Upload, Shield, Target, Activity, HelpCircle, Search,
  MessageCircle, Send, Loader2, Bookmark, X, Users,
} from 'lucide-react';

type TopAthleteRow = { profile_id: string; sport: string; rank_score: number; profiles: Profile };
type FeedPostRow = Post & { profiles: Profile };
type SavedPostRow = { post_id: string; posts: FeedPostRow };

export default function DashboardPage() {
  const { profile, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [topAthletes, setTopAthletes] = useState<TopAthleteRow[]>([]);
  const [loadingAthletes, setLoadingAthletes] = useState(true);
  const [quickPostContent, setQuickPostContent] = useState('');
  const [posting, setPosting] = useState(false);
  const [postSuccess, setPostSuccess] = useState(false);
  const [recentPosts, setRecentPosts] = useState<FeedPostRow[]>([]);
  const [savedPosts, setSavedPosts] = useState<SavedPostRow[]>([]);
  const [isLoadingSaved, setIsLoadingSaved] = useState(true);

  // Real stats for the logged-in athlete: rank score, follower/following
  // counts, and achievement count — none of these are columns on
  // `profiles`, they're computed from their own tables.
  const [myScore, setMyScore] = useState<number | null>(null);
  const [scorePoolCount, setScorePoolCount] = useState<number | null>(null);
  const [latestMovement, setLatestMovement] = useState<{
    rank_score: number | null; previous_rank_score: number | null;
    leaderboard_position: number | null; previous_position: number | null;
    sport: string; trigger_reason: string; recorded_at: string;
  } | null | undefined>(undefined); // undefined = loading, null = no history
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [achievementCount, setAchievementCount] = useState(0);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    if (!profile) return;
    let active = true;
    setLoadingStats(true);

    Promise.all([
      supabase.from('rankings').select('rank_score, sport')
        .eq('profile_id', profile.id).eq('division', 'Open')
        .order('rank_score', { ascending: false }).limit(1).maybeSingle(),
      supabase.from('rank_history')
        .select('rank_score,previous_rank_score,leaderboard_position,previous_position,sport,trigger_reason,recorded_at')
        .eq('profile_id', profile.id).eq('division', 'Open')
        .order('recorded_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase.from('follows').select('*', { count: 'exact', head: true }).eq('following_id', profile.id),
      supabase.from('follows').select('*', { count: 'exact', head: true }).eq('follower_id', profile.id),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('profile_id', profile.id).eq('post_type', 'achievement'),
    ]).then(([rankingRes, movementRes, followersRes, followingRes, achievementsRes]) => {
      if (!active) return;
      const bestRanking = rankingRes.data as { rank_score: number; sport?: string } | null;
      setMyScore(bestRanking?.rank_score ?? null);
      if (bestRanking?.sport) {
        supabase.from('rankings').select('profile_id')
          .eq('sport', bestRanking.sport).eq('division', 'Open')
          .then(({ data }) => {
            const distinct = new Set((data ?? []).map((r: { profile_id: string }) => r.profile_id)).size;
            setScorePoolCount(Math.max(distinct, 1));
          });
      }
      setLatestMovement((movementRes.data as typeof latestMovement) ?? null);
      setFollowerCount(followersRes.count ?? 0);
      setFollowingCount(followingRes.count ?? 0);
      setAchievementCount(achievementsRes.count ?? 0);
      setLoadingStats(false);
    });

    return () => { active = false; };
  }, [profile?.id]);

  // Top athletes leaderboard preview — two separate queries merged client-side.
  // Must filter to division='Open' after SQL #93 so each athlete appears once
  // (rankings now has one row per profile_id+sport+division).
  useEffect(() => {
    supabase
      .from('rankings')
      .select('profile_id, sport, rank_score, division')
      .eq('division', 'Open')
      .order('rank_score', { ascending: false })
      .limit(50)
      .then(async ({ data: rankData, error: rankError }) => {
        if (rankError) { console.error('Failed to load rankings:', rankError.message); setLoadingAthletes(false); return; }
        if (!rankData || rankData.length === 0) { setTopAthletes([]); setLoadingAthletes(false); return; }

        // Diagnostic: confirm Supabase returns the precise value (e.g. 66.67 not 67).
        // Remove after confirming the rounding source.
        const first = rankData[0] as { rank_score: unknown };
        console.error('[score-diagnostic]', {
          rawRankScore: first?.rank_score,
          numericRankScore: Number(first?.rank_score),
          displayedRankScore: Number(first?.rank_score).toFixed(2),
        });

        // Deduplicate: one row per profile_id, keeping the highest rank_score.
        // An athlete with AFL and Swimming both ranked in Open produces two rows;
        // we only show their best score in this list.
        const bestByProfile = new Map<string, { profile_id: string; sport: string; rank_score: number }>();
        for (const r of rankData as { profile_id: string; sport: string; rank_score: number }[]) {
          const existing = bestByProfile.get(r.profile_id);
          if (!existing || Number(r.rank_score) > Number(existing.rank_score)) {
            bestByProfile.set(r.profile_id, r);
          }
        }
        const deduped = [...bestByProfile.values()]
          .sort((a, b) => Number(b.rank_score) - Number(a.rank_score));

        const profileIds = deduped.map(r => r.profile_id);
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('id, username, first_name, last_name, avatar_url, role, scoutrank_score')
          .in('id', profileIds)
          .eq('role', 'athlete');

        if (profileError) { console.error('Failed to load profiles:', profileError.message); setLoadingAthletes(false); return; }

        const profileMap = Object.fromEntries(
          ((profileData ?? []) as { id: string; username: string; first_name: string; last_name: string; avatar_url: string | null; role: string; scoutrank_score: number | null }[])
            .map(p => [p.id, p])
        );
        const athletes = deduped
          .filter(r => profileMap[r.profile_id])
          .map(r => ({ ...r, profiles: profileMap[r.profile_id] }))
          .slice(0, 5) as TopAthleteRow[];

        setTopAthletes(athletes);
        setLoadingAthletes(false);
      });
  }, []);

  // Latest community posts (real, from Supabase)
  useEffect(() => {
    loadRecentPosts();
  }, []);

  // Saved posts — private to this user, requires profile to be loaded
  useEffect(() => {
    if (!profile) return;
    setIsLoadingSaved(true);
    supabase
      .from('saved_posts')
      .select('post_id, posts(*, profiles(*))')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (error) console.error('Failed to load saved posts:', error.message);
        setSavedPosts((data as unknown as SavedPostRow[] | null) ?? []);
        setIsLoadingSaved(false);
      });
  }, [profile?.id]);

  const handleUnsave = async (postId: string) => {
    if (!profile) return;
    const { error } = await supabase
      .from('saved_posts')
      .delete()
      .eq('post_id', postId)
      .eq('profile_id', profile.id);
    if (error) {
      console.error('Failed to unsave post:', error.message);
      return;
    }
    setSavedPosts(prev => prev.filter(s => s.post_id !== postId));
  };

  if (!profile) return null;

  // Calculate profile completeness based on actual data
  let completeness = 10;
  if (profile.bio) completeness += 15;
  if (profile.city) completeness += 10;
  if (profile.age) completeness += 10;
  if (achievementCount > 0) completeness += 20;
  if (followerCount > 0) completeness += 10;
  if (followingCount > 0) completeness += 10;
  completeness = Math.min(completeness, 100);

  const isParent = profile.role === 'parent';

  const suggestedActions = [
    { icon: Upload, label: 'Upload a Highlight', desc: 'Add game footage or clips', to: `/profile/${profile.username}?tab=highlights`, show: !isParent },
    { icon: Award, label: 'Add Achievement', desc: 'Submit your first achievement', to: `/profile/${profile.username}?tab=achievements`, show: !isParent },
    { icon: FileText, label: 'Complete Bio', desc: 'Tell your sporting story', to: '/settings', show: !isParent },
    { icon: Search, label: 'Browse Athletes', desc: 'Discover other athletes', to: '/discover', show: true },
    { icon: Sparkles, label: 'Generate AI Resume', desc: 'Create your athlete CV', to: `/profile/${profile.username}?tab=resume`, show: !isParent },
    { icon: Shield, label: 'Verification Centre', desc: 'Get verified as a coach or scout', to: '/verification-status', show: profile.role === 'coach' || profile.role === 'scout' },
    { icon: Users, label: 'My Athletes', desc: 'View your linked athletes', to: '/parent', show: isParent },
  ].filter(a => a.show);

  const handleQuickPost = async () => {
    if (posting || !quickPostContent.trim() || !profile) return;
    if (isParent) return; // parents cannot post
    setPosting(true);
    const { error } = await supabase.from('posts').insert({
      profile_id: profile.id,
      caption: quickPostContent,
      media_url: null,
      sport_tag: null,
    });
    setPosting(false);
    if (error) {
      console.error('Failed to create post:', error.message);
      return;
    }
    setQuickPostContent('');
    setPostSuccess(true);
    setTimeout(() => setPostSuccess(false), 2500);
    loadRecentPosts();
  };

  function loadRecentPosts() {
    supabase
      .from('posts')
      .select('*, profiles(*)')
      .order('created_at', { ascending: false })
      .limit(3)
      .then(({ data, error }) => {
        if (error) console.error('Failed to load recent posts:', error.message);
        setRecentPosts((data as unknown as FeedPostRow[] | null) ?? []);
      });
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">
          Welcome, <span className="gradient-text-brand">{profile.first_name}</span>
        </h1>
        <p className="text-sr-text-muted mt-1">Your ScoutRank dashboard</p>
        {isAdmin && (
          <div className="mt-3">
            <Button variant="brand" size="sm" icon={<Shield className="h-4 w-4" />} onClick={() => navigate('/admin')}>
              Admin Dashboard
            </Button>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main */}
        <div className="lg:col-span-2 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { icon: BarChart3, label: 'ScoutRank Score', value: loadingStats ? '—' : (myScore !== null ? displayScoutRank(myScore) : 'Not ranked yet'), color: 'from-sr-purple to-sr-blue', poolCount: scorePoolCount },
              { icon: TrendingUp, label: 'Followers', value: loadingStats ? '—' : followerCount.toString(), color: 'from-green-400 to-emerald-500' },
              { icon: Activity, label: 'Following', value: loadingStats ? '—' : followingCount.toString(), color: 'from-sr-blue to-cyan-400' },
              { icon: Award, label: 'Achievements', value: loadingStats ? '—' : achievementCount.toString(), color: 'from-sr-violet to-sr-purple' },
            ].map(stat => (
              <div key={stat.label} className="card-premium p-4">
                <div className={`h-8 w-8 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-2`}>
                  <stat.icon className="h-4 w-4 text-white" />
                </div>
                <div className="text-xl font-bold text-white">{stat.value}</div>
                <div className="text-xs text-sr-text-muted">{stat.label}</div>
                {(stat as { poolCount?: number | null }).poolCount !== undefined && (() => {
                  const trust = getTrustMeta((stat as { poolCount?: number | null }).poolCount ?? 1);
                  return trust ? (
                    <span title={trust.tooltip}
                      className={`mt-1 inline-block text-[10px] font-semibold px-1.5 py-0.5 rounded border bg-sr-surface cursor-help ${trust.cls}`}>
                      {trust.label}
                    </span>
                  ) : null;
                })()}
              </div>
            ))}
          </div>

          {/* Latest movement card */}
          {latestMovement !== undefined && (
            <div className="card-premium p-4">
              <p className="text-xs font-semibold text-sr-text-muted uppercase tracking-wide mb-3">Latest ScoutRank Movement</p>
              {latestMovement === null ? (
                <div>
                  <p className="text-sm text-sr-silver">No ScoutRank movement yet</p>
                  <p className="text-xs text-sr-text-muted mt-0.5">Get a stat verified to enter the rankings.</p>
                </div>
              ) : (() => {
                const h = latestMovement;
                const newlyRanked    = h.previous_rank_score == null && h.rank_score != null;
                const becameUnranked = h.previous_rank_score != null && h.rank_score == null;
                const scoreDelta = h.rank_score != null && h.previous_rank_score != null
                  ? Math.round((Number(h.rank_score) - Number(h.previous_rank_score)) * 100) / 100
                  : null;

                const posDelta = h.leaderboard_position != null && h.previous_position != null
                  ? h.previous_position - h.leaderboard_position : null;
                const isUp   = newlyRanked || (posDelta != null && posDelta > 0) || (scoreDelta != null && scoreDelta > 0);
                const isDown = becameUnranked || (posDelta != null && posDelta < 0) || (scoreDelta != null && scoreDelta < 0);
                const sportLabel = h.sport.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                const reasonLabel = ({
                  stat_verified: 'Stat verified',
                  stat_unverified: 'Stat unverified',
                  stat_deleted: 'Stat deleted',
                  full_recalculation: 'Recalculation',
                } as Record<string,string>)[h.trigger_reason] ?? h.trigger_reason.replace(/_/g, ' ');

                return (
                  <div className="flex items-center justify-between">
                    <div>
                      {newlyRanked ? (
                        <p className="text-sm font-semibold text-green-400">Earned first ScoutRank</p>
                      ) : becameUnranked ? (
                        <p className="text-sm font-semibold text-red-400">Became unranked</p>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          {isUp && <TrendUpIcon size={14} className="text-green-400" />}
                          {isDown && <TrendDownIcon size={14} className="text-red-400" />}
                          <p className={`text-sm font-bold font-mono ${isUp ? 'text-green-400' : isDown ? 'text-red-400' : 'text-sr-silver'}`}>
                            {scoreDelta != null ? `${scoreDelta > 0 ? '+' : ''}${scoreDelta.toFixed(2)}` : '—'}
                          </p>
                        </div>
                      )}
                      <p className="text-xs text-sr-text-muted mt-0.5">
                        {sportLabel} · {reasonLabel}
                        {h.previous_position != null && h.leaderboard_position != null && (
                          <span> · #{h.previous_position} → #{h.leaderboard_position}</span>
                        )}
                        {newlyRanked && h.leaderboard_position != null && (
                          <span> · Entered at #{h.leaderboard_position}</span>
                        )}
                      </p>
                    </div>
                    {!newlyRanked && !becameUnranked && h.rank_score != null && (
                      <div className="text-right">
                        <p className="text-xs text-sr-text-muted">Score</p>
                        <p className="text-sm font-bold text-white">{displayScoutRank(h.rank_score)}</p>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* Profile Completeness */}
          <div className="card-premium p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white">Profile Completeness</h3>
              <span className="text-sm font-bold gradient-text-brand">{completeness}%</span>
            </div>
            <div className="h-2 bg-sr-surface rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-sr-purple to-sr-blue rounded-full transition-all duration-500"
                style={{ width: `${completeness}%` }} />
            </div>
            <p className="text-xs text-sr-text-muted mt-3">
              Complete your profile to unlock your ScoutRank score and start climbing the rankings. Add a bio, stats and highlights — get your stats verified to earn a score.
            </p>
          </div>

          {/* Scoring Info Card */}
          <div className="card-premium p-6">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <HelpCircle className="h-4 w-4 text-sr-purple" />
              How ScoutRank Scoring Works
            </h3>
            <div className="space-y-3">
              <div className="rounded-lg bg-sr-surface border border-sr-border p-3">
                <p className="text-xs font-medium text-sr-silver mb-1">ScoutRank Score (0.00 – 100.00)</p>
                <p className="text-xs text-sr-text-muted leading-relaxed">Your percentile rank among all athletes with verified stats in the same event. At the 85th percentile you score 85.00.</p>
              </div>
              <div className="rounded-lg bg-sr-surface border border-sr-border p-3">
                <p className="text-xs font-medium text-sr-silver mb-1">Open division — your displayed score</p>
                <p className="text-xs text-sr-text-muted leading-relaxed">
                  Your displayed score is your best result in the <span className="text-sr-silver">Open</span> division — compared across all ages. Youth athletes automatically appear in older divisions too (U17 athletes appear in U17, U18 and Open) without any extra submissions.
                </p>
              </div>
              <div className="rounded-lg bg-sr-surface border border-sr-border p-3">
                <p className="text-xs font-medium text-sr-silver mb-1">How to improve</p>
                <p className="text-xs text-sr-text-muted leading-relaxed">Submit stats with photo/video evidence. An admin reviews and verifies each result. Your score updates automatically.</p>
              </div>
              <div className="rounded-lg bg-sr-purple/10 border border-sr-purple/20 p-3">
                <p className="text-xs text-sr-silver">Achievements, posts and follows do not affect your ScoutRank score. Only verified stats count.</p>
              </div>
            </div>
          </div>

          {/* Suggested Actions */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Target className="h-4 w-4 text-sr-purple" />
              Get Started
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {suggestedActions.map(action => (
                <button key={action.label} onClick={() => navigate(action.to)}
                  className="card-premium p-4 text-left hover:border-sr-purple/30 transition-all group">
                  <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sr-purple/20 to-sr-blue/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <action.icon className="h-5 w-5 text-sr-purple-light" />
                  </div>
                  <p className="text-sm font-semibold text-white">{action.label}</p>
                  <p className="text-xs text-sr-text-muted mt-1">{action.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Post — hidden for parents */}
          {!isParent && (
          <div className="card-premium p-4">
            <h3 className="text-sm font-semibold text-white mb-3">Quick Post</h3>
            {postSuccess && (
              <div className="mb-3 p-2 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 text-xs">
                Post shared to the Feed!
              </div>
            )}
            <textarea
              className="input-dark h-20 resize-none text-sm"
              placeholder="Share an update, game result, or milestone..."
              value={quickPostContent}
              onChange={e => setQuickPostContent(e.target.value)}
            />
            <div className="flex justify-end mt-2">
              <Button variant="brand" size="sm"
                icon={posting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                disabled={!quickPostContent.trim() || posting}
                onClick={handleQuickPost}>
                {posting ? 'Posting...' : 'Post'}
              </Button>
            </div>
          </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Top Athletes Leaderboard */}
          <div className="card-premium p-6">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-sr-purple" />
              Top Athletes
            </h3>
            {loadingAthletes ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-5 w-5 text-sr-text-muted animate-spin" />
              </div>
            ) : topAthletes.length === 0 ? (
              <p className="text-xs text-sr-text-muted text-center py-4">
                No athletes yet. Be the first to join the rankings!
              </p>
            ) : (
              <div className="space-y-1">
                {topAthletes.map((row, i) => (
                  <Link
                    key={row.profile_id}
                    to={`/profile/${row.profiles.username}`}
                    className="flex items-center gap-2 p-2 rounded-lg hover:bg-sr-surface-light/50 transition-colors">
                    <span className="w-6 text-center text-xs font-bold text-sr-text-muted">#{i + 1}</span>
                    <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-sr-purple/40 to-sr-blue/40 flex items-center justify-center text-[10px] font-bold text-white">
                      {row.profiles.first_name?.[0]}{row.profiles.last_name?.[0]}
                    </div>
                    <span className="text-xs text-sr-silver flex-1 truncate">{fullName(row.profiles)}</span>
                    <span className="text-xs font-bold text-white">{displayScoutRank(row.rank_score)}</span>
                  </Link>
                ))}
              </div>
            )}
            <Link to="/rankings" className="text-xs text-sr-purple-light hover:underline mt-3 inline-block">View full rankings →</Link>
          </div>

          {/* Recent Community Posts */}
          <div className="card-premium p-6">
            <h3 className="text-sm font-semibold text-white mb-4">Latest on ScoutRank</h3>
            {recentPosts.length === 0 ? (
              <p className="text-xs text-sr-text-muted text-center py-4">
                No community posts yet. Share something on the Feed!
              </p>
            ) : (
              <div className="space-y-3">
                {recentPosts.map(post => (
                  <div key={post.id} className="p-3 rounded-lg bg-sr-surface/50 border border-sr-border/50">
                    <div className="flex items-center gap-2 mb-1">
                      {post.sport_tag && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-sr-purple/10 text-sr-purple-light">
                          {post.sport_tag}
                        </span>
                      )}
                      <span className="text-[10px] text-sr-text-muted">@{post.profiles?.username || 'athlete'}</span>
                    </div>
                    <p className="text-xs text-sr-silver line-clamp-2">{post.caption}</p>
                  </div>
                ))}
              </div>
            )}
            <Link to="/feed" className="text-xs text-sr-purple-light hover:underline mt-3 inline-block">
              <MessageCircle className="inline h-3 w-3 mr-1" />Go to Feed →
            </Link>
          </div>

          {/* Saved Posts — private to this user */}
          <div className="card-premium p-6">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Bookmark className="h-4 w-4 text-sr-purple" />Saved Posts
            </h3>
            {isLoadingSaved ? (
              <p className="text-xs text-sr-text-muted text-center py-4">Loading...</p>
            ) : savedPosts.length === 0 ? (
              <p className="text-xs text-sr-text-muted text-center py-4">
                Nothing saved yet. Tap the bookmark icon on a post in the Feed to save it here.
              </p>
            ) : (
              <div className="space-y-3">
                {savedPosts.map(saved => (
                  <div key={saved.post_id} className="p-3 rounded-lg bg-sr-surface/50 border border-sr-border/50 flex items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <span className="text-[10px] text-sr-text-muted">@{saved.posts?.profiles?.username || 'athlete'}</span>
                      <p className="text-xs text-sr-silver line-clamp-2">{saved.posts?.caption}</p>
                    </div>
                    <button onClick={() => handleUnsave(saved.post_id)}
                      className="text-sr-text-muted hover:text-white flex-shrink-0" title="Remove from saved">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
