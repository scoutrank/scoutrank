import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, fullName } from '@/lib/supabase';
import type { Organisation, Profile } from '@/lib/supabase';
import { VerificationBadge } from '@/components/ui/VerificationBadge';
import { SafeProfileLink } from '@/components/ui/SafeProfileLink';
import { formatSportName } from '@/utils/format';
import {
  Building2, MapPin, Globe, Shield, Users,
  Trophy, Newspaper, ChevronRight, Loader2, AlertCircle,
} from 'lucide-react';

// ─── types ────────────────────────────────────────────────────────────────────

interface AffiliatedCoach extends Profile {
  role_title: string | null; // from the verification_submission
}

// ─── org type display ─────────────────────────────────────────────────────────

const ORG_TYPE_LABEL: Record<string, string> = {
  club: 'Sporting Club',
  school: 'School',
  academy: 'Academy',
  organisation: 'Sporting Organisation',
};

// ─── page ─────────────────────────────────────────────────────────────────────

export default function OrganisationProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser, profile: viewerProfile } = useAuth();
  const [org, setOrg]           = useState<Organisation | null>(null);
  const [coaches, setCoaches]   = useState<AffiliatedCoach[]>([]);
  const [activeTab, setActiveTab] = useState<'coaches' | 'athletes' | 'teams' | 'posts'>('coaches');
  const [isLoading, setIsLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) return;
    setIsLoading(true);

    // 1. Load the organisation.
    supabase
      .from('organisations')
      .select('*')
      .eq('id', id)
      .single()
      .then(async ({ data: orgData, error: orgError }) => {
        if (orgError || !orgData) { setNotFound(true); setIsLoading(false); return; }
        setOrg(orgData as Organisation);

        // 2. Load verified coaches/scouts affiliated via verification_submissions.
        // verification_submissions.organisation_id links a coach's approved
        // verification to a specific org. We only show verified accounts.
        const { data: subData, error: subError } = await supabase
          .from('verification_submissions')
          .select('profile_id, role_title, status')
          .eq('organisation_id', id)
          .eq('status', 'approved');

        if (subError) { console.error('[org-profile] submissions error:', subError.message); setIsLoading(false); return; }

        const profileIds = [...new Set((subData ?? []).map((s: { profile_id: string }) => s.profile_id))];
        const roleByProfile: Record<string, string> = {};
        for (const s of (subData ?? []) as { profile_id: string; role_title: string }[]) {
          roleByProfile[s.profile_id] = s.role_title;
        }

        if (profileIds.length > 0) {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('*')
            .in('id', profileIds)
            .eq('coach_scout_verification_status', 'verified');

          if (profileError) { console.error('[org-profile] profiles error:', profileError.message); }

          const affiliated: AffiliatedCoach[] = ((profileData as Profile[] | null) ?? []).map(p => ({
            ...p,
            role_title: roleByProfile[p.id] ?? null,
          }));
          setCoaches(affiliated);
        }

        setIsLoading(false);
      });
  }, [id]);

  if (isLoading) return (
    <div className="flex items-center justify-center py-24">
      <Loader2 className="h-8 w-8 text-sr-purple animate-spin" />
    </div>
  );

  if (notFound || !org) return (
    <div className="max-w-2xl mx-auto px-4 py-24 text-center">
      <AlertCircle className="h-12 w-12 mx-auto text-sr-text-muted mb-4" />
      <h1 className="text-xl font-bold text-white mb-2">Organisation Not Found</h1>
      <p className="text-sr-text-muted">This organisation doesn't exist or has been removed.</p>
    </div>
  );

  const TABS = [
    { id: 'coaches' as const, label: 'Coaches & Scouts', icon: Shield, count: coaches.length },
    { id: 'athletes' as const, label: 'Athletes', icon: Users, count: null },
    { id: 'teams' as const, label: 'Teams', icon: Trophy, count: null },
    { id: 'posts' as const, label: 'Posts', icon: Newspaper, count: null },
  ];

  return (
    <div className="min-h-screen">
      {/* Banner */}
      <div className="h-48 sm:h-64 relative overflow-hidden">
        {/* Gradient banner — same pattern as AthleteProfilePage fallback */}
        <div className="absolute inset-0 bg-gradient-to-br from-sr-surface to-sr-bg" />
        <div className="absolute inset-0 bg-gradient-to-t from-sr-bg via-transparent to-transparent" />
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_30%_50%,rgba(138,63,252,0.4),transparent_55%)]" />
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_70%_30%,rgba(59,130,246,0.3),transparent_50%)]" />
      </div>

      {/* Header */}
      <div className="max-w-6xl mx-auto px-4">
        <div className="relative -mt-20 sm:-mt-24 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            {/* Org logo / placeholder */}
            <div className="h-28 w-28 sm:h-36 sm:w-36 rounded-2xl border-4 border-sr-bg shadow-xl glow-brand flex-shrink-0 overflow-hidden bg-gradient-to-br from-sr-purple to-sr-blue flex items-center justify-center">
              <Building2 className="h-14 w-14 sm:h-18 sm:w-18 text-white/90" />
            </div>

            <div className="flex-1 pb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-bold text-white">{org.name}</h1>
                {org.verified && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-sr-purple/20 to-sr-blue/20 border border-sr-purple/30 text-white">
                    <div className="h-3 w-3 rounded-full bg-gradient-to-br from-sr-purple to-sr-blue flex items-center justify-center flex-shrink-0">
                      <Shield className="h-2 w-2 text-white" strokeWidth={3} />
                    </div>
                    Verified Organisation
                  </span>
                )}
              </div>
              <p className="text-sm text-sr-text-muted mt-0.5">{ORG_TYPE_LABEL[org.type] ?? org.type}</p>

              {/* Meta row */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-sr-text-muted">
                {(org.city || org.state || org.country) && (
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5" />
                    {[org.city, org.state, org.country].filter(Boolean).join(', ')}
                  </span>
                )}
                {org.website && (
                  <a href={org.website} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 text-sr-purple-light hover:text-sr-purple transition-colors">
                    <Globe className="h-3.5 w-3.5" />
                    {org.website.replace(/^https?:\/\//, '')}
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sports tags */}
        {org.sports.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {org.sports.map(s => (
              <span key={s} className="px-3 py-1 rounded-full text-xs font-medium bg-sr-surface border border-sr-border text-sr-silver">
                {formatSportName(s)}
              </span>
            ))}
          </div>
        )}

        {/* Tab bar — matches AthleteProfilePage pattern */}
        <div className="flex gap-0 overflow-x-auto mb-6 border-b border-sr-border">
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-all -mb-px ${
                activeTab === tab.id
                  ? 'border-sr-purple text-white'
                  : 'border-transparent text-sr-text-muted hover:text-sr-silver'
              }`}>
              <tab.icon className="h-4 w-4" />
              {tab.label}
              {tab.count !== null && tab.count > 0 && (
                <span className="text-xs bg-sr-surface border border-sr-border px-1.5 py-0.5 rounded-full">{tab.count}</span>
              )}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="pb-16">
          {activeTab === 'coaches' && (
            <div className="space-y-4">
              {coaches.length === 0 ? (
                <div className="card-premium p-12 text-center">
                  <Shield className="h-10 w-10 mx-auto text-sr-text-muted mb-3" />
                  <p className="text-white font-semibold mb-1">No Verified Coaches Yet</p>
                  <p className="text-sm text-sr-text-muted">
                    Verified coaches and scouts who listed this organisation will appear here.
                  </p>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {coaches.map(coach => (
                    <SafeProfileLink
                      key={coach.id}
                      targetProfile={coach}
                      viewerProfile={viewerProfile}
                      viewerUserId={currentUser?.id}
                      className="card-premium p-5 hover:border-sr-purple/30 transition-colors group block"
                    >
                      <div className="flex items-center gap-3 mb-3">
                        {/* Avatar */}
                        <div className="h-12 w-12 rounded-xl overflow-hidden flex-shrink-0">
                          {coach.avatar_url ? (
                            <img src={coach.avatar_url} alt={fullName(coach)} className="h-full w-full object-cover" />
                          ) : (
                            <div className="h-full w-full bg-gradient-to-br from-sr-purple to-sr-blue flex items-center justify-center text-white text-sm font-bold">
                              {coach.first_name?.[0]}{coach.last_name?.[0]}
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-white truncate group-hover:text-sr-purple-light transition-colors">
                            {fullName(coach)}
                          </p>
                          <p className="text-xs text-sr-text-muted truncate">
                            {coach.role_title ?? (coach.role === 'coach' ? 'Coach' : 'Scout')}
                          </p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-sr-text-muted group-hover:text-sr-purple-light transition-colors flex-shrink-0" />
                      </div>
                      <VerificationBadge status={coach.coach_scout_verification_status} role={coach.role} size="sm" />
                    </SafeProfileLink>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'athletes' && (
            <div className="card-premium p-12 text-center">
              <Users className="h-10 w-10 mx-auto text-sr-text-muted mb-3" />
              <p className="text-white font-semibold mb-1">Athletes — Coming Soon</p>
              <p className="text-sm text-sr-text-muted">Athletes affiliated with this organisation will appear here.</p>
            </div>
          )}

          {activeTab === 'teams' && (
            <div className="card-premium p-12 text-center">
              <Trophy className="h-10 w-10 mx-auto text-sr-text-muted mb-3" />
              <p className="text-white font-semibold mb-1">Teams — Coming Soon</p>
              <p className="text-sm text-sr-text-muted">Teams and squads associated with this organisation will appear here.</p>
            </div>
          )}

          {activeTab === 'posts' && (
            <div className="card-premium p-12 text-center">
              <Newspaper className="h-10 w-10 mx-auto text-sr-text-muted mb-3" />
              <p className="text-white font-semibold mb-1">Posts — Coming Soon</p>
              <p className="text-sm text-sr-text-muted">News and updates from this organisation will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
