import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '@/components/ui/Logo';
import { Button } from '@/components/ui/Button';
import { supabase } from '@/lib/supabase';
import { ArrowRight, BarChart3, Shield, Trophy, Video, Sparkles, Search, TrendingUp, Medal, Users } from 'lucide-react';

const features = [
  { icon: Trophy, title: 'Build Your Athlete Profile', desc: 'Create a premium sporting identity. Showcase your sports, stats, positions, achievements and journey.' },
  { icon: BarChart3, title: 'Climb the Rankings', desc: 'Compete on the global ScoutRank leaderboard. Track your rank movement across local, state, national and global levels.' },
  { icon: Video, title: 'Share Highlights', desc: 'Upload game footage, training clips and media. Let your performance speak for itself with a rich media gallery.' },
  { icon: Shield, title: 'Get Verified', desc: 'Submit achievements, stats and milestones for verification. Build a trusted reputation that coaches and scouts rely on.' },
  { icon: Sparkles, title: 'AI-Powered Insights', desc: 'Get AI-generated overviews of your sporting profile. Generate professional athlete resumes with one click.' },
  { icon: Search, title: 'Get Discovered', desc: 'Be found by coaches, scouts and clubs. Your verified profile and rankings make you impossible to miss.' },
];

// Real scoring categories (not fake athlete data) — illustrative of how
// rankings actually work, shown on the landing page before real users exist.
const scoringPreview = [
  { icon: Trophy, label: 'Verified achievements', points: '+5 to +15' },
  { icon: BarChart3, label: 'Verified stats & PBs', points: '+3 to +8' },
  { icon: Medal, label: 'Competition results', points: '+2 to +10' },
  { icon: Users, label: 'Scout/coach endorsements', points: '+3 to +8' },
];

// "1 Athlete" vs "2 Athletes" — proper singular/plural, not just the number
function pluralize(count: number, singular: string, plural: string): string {
  return count === 1 ? singular : plural;
}

export default function LandingPage() {
  const navigate = useNavigate();
  const [liveStats, setLiveStats] = useState<{ athletes: number; clubs: number; posts: number } | null>(null);

  useEffect(() => {
    let active = true;

    Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'athlete'),
      supabase.from('athlete_details').select('club').not('club', 'is', null).neq('club', ''),
      supabase.from('posts').select('*', { count: 'exact', head: true }),
    ]).then(([athletesRes, clubsRes, postsRes]) => {
      if (!active) return;
      // No real `clubs` table exists yet — count distinct, non-empty
      // club names athletes have actually entered on their profile.
      const distinctClubs = new Set(
        (clubsRes.data ?? []).map((row: { club: string }) => row.club.trim().toLowerCase())
      ).size;

      setLiveStats({
        athletes: athletesRes.count ?? 0,
        clubs: distinctClubs,
        posts: postsRes.count ?? 0,
      });
    });

    return () => { active = false; };
  }, []);

  return (
    <div className="min-h-screen bg-sr-bg overflow-x-hidden">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-sr-bg/90 backdrop-blur-xl border-b border-sr-border">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Logo size="sm" withText={true} />
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('/login')}>Log In</Button>
            <Button variant="brand" size="sm" onClick={() => navigate('/signup')}>Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-1/2 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-sr-purple/10 blur-[120px]" />
          <div className="absolute top-1/4 right-0 w-[400px] h-[400px] rounded-full bg-sr-blue/10 blur-[100px]" />
        </div>

        <div className="relative max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-sr-purple/10 border border-sr-purple/20 text-sr-purple-light text-sm font-medium mb-8">
            <Sparkles className="h-4 w-4" />
            The Future of Athlete Identity
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold tracking-tight mb-6">
            <span className="gradient-text">Rank, Rise</span>
            <br />
            <span className="gradient-text">and Repeat</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-sr-text-muted max-w-2xl mx-auto mb-10 leading-relaxed">
            The premium sports social platform where athletes build their identity, 
            climb the rankings, share highlights, and get discovered by coaches and scouts worldwide.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-16">
            <Button variant="brand" size="lg" onClick={() => navigate('/signup')} icon={<ArrowRight className="h-5 w-5" />}>
              Start Building Your Profile
            </Button>
            <Button variant="outline" size="lg" onClick={() => navigate('/rankings')}>
              Explore Rankings
            </Button>
          </div>

          {/* Hero Stats — live counts from the database, not fake numbers */}
          <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
            {[
              { value: liveStats?.athletes, label: pluralize(liveStats?.athletes ?? 0, 'Athlete', 'Athletes') },
              { value: liveStats?.clubs, label: pluralize(liveStats?.clubs ?? 0, 'Club', 'Clubs') },
              { value: liveStats?.posts, label: pluralize(liveStats?.posts ?? 0, 'Post', 'Posts') },
            ].map(stat => (
              <div key={stat.label} className="card-premium p-4">
                <div className="text-2xl font-bold gradient-text-brand">
                  {stat.value === undefined ? <span className="inline-block w-8 h-6 bg-sr-surface-light rounded animate-pulse" /> : stat.value.toLocaleString()}
                </div>
                <div className="text-xs text-sr-text-muted mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leaderboard Preview */}
      <section className="py-20 px-4 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-display font-bold gradient-text mb-4">How Rankings Work</h2>
            <p className="text-sr-text-muted max-w-xl mx-auto">Your ScoutRank score is built from verified performance stats — not who you know.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Scoring breakdown (real, not fake leaderboard data) */}
            <div className="lg:col-span-2 card-premium p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-sr-purple" />
                  How You Earn Points
                </h3>
              </div>
              <div className="space-y-1">
                {scoringPreview.map((entry) => (
                  <div
                    key={entry.label}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-sr-surface-light/50 transition-colors"
                  >
                    <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-sr-purple/30 to-sr-blue/30 flex items-center justify-center flex-shrink-0">
                      <entry.icon className="h-4 w-4 text-sr-purple-light" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{entry.label}</p>
                    </div>
                    <span className="text-sm font-bold gradient-text-brand">{entry.points}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-sr-text-muted mt-4">Full scoring breakdown is visible on every profile once you sign up.</p>
            </div>

            {/* Honest founding-athlete CTA — no fake profiles */}
            <div className="card-premium p-6 flex flex-col items-center justify-center text-center gap-3">
              <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-sr-purple to-sr-blue flex items-center justify-center">
                <Medal className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-base font-bold text-white">Rankings start with you</h3>
              <p className="text-sm text-sr-text-muted">ScoutRank just launched — there's no leaderboard yet because there's no one on it. Be one of the first verified athletes and claim #1.</p>
              <Button variant="brand" size="sm" onClick={() => navigate('/signup')} icon={<ArrowRight className="h-4 w-4" />}>
                Claim Your Profile
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute bottom-0 left-1/4 w-[500px] h-[500px] rounded-full bg-sr-blue/5 blur-[100px]" />
        </div>
        <div className="relative max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold gradient-text mb-4">Everything You Need</h2>
            <p className="text-sr-text-muted max-w-xl mx-auto">Built for athletes who want to be seen, ranked, and recognized.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map(f => (
              <div key={f.title} className="card-premium p-6 group hover:border-sr-purple/30 transition-all duration-300">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sr-purple/20 to-sr-blue/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <f.icon className="h-5 w-5 text-sr-purple-light" />
                </div>
                <h3 className="text-base font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-sm text-sr-text-muted leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="card-premium p-8 sm:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-sr-purple/10 rounded-full blur-[80px]" />
            <div className="relative grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sr-purple/10 border border-sr-purple/20 text-sr-purple-light text-sm font-medium mb-6">
                  <Sparkles className="h-4 w-4" /> Powered by AI
                </div>
                <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
                  AI That Understands
                  <br />
                  <span className="gradient-text-brand">Your Game</span>
                </h2>
                <p className="text-sr-text-muted leading-relaxed mb-6">
                  ScoutRank AI analyzes your profile, stats, achievements and rankings to generate intelligent overviews of your sporting identity. Build professional athlete resumes with one click. Get insights that help you understand where you stand and where you're heading.
                </p>
                <div className="flex flex-wrap gap-3">
                  {['Athlete Overviews', 'Resume Builder', 'Performance Analysis', 'Ranking Insights'].map(tag => (
                    <span key={tag} className="px-3 py-1 rounded-full bg-sr-surface-light border border-sr-border text-xs text-sr-silver">{tag}</span>
                  ))}
                </div>
              </div>
              <div className="bg-sr-bg/80 rounded-xl p-6 border border-sr-border">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="h-4 w-4 text-sr-purple" />
                  <span className="text-xs font-medium text-sr-purple-light">AI ATHLETE OVERVIEW</span>
                </div>
                <div className="space-y-3">
                  <div className="h-3 bg-sr-surface-light rounded w-3/4 animate-shimmer" />
                  <div className="h-3 bg-sr-surface-light rounded w-full animate-shimmer" />
                  <div className="h-3 bg-sr-surface-light rounded w-5/6 animate-shimmer" />
                  <div className="h-3 bg-sr-surface-light rounded w-2/3 animate-shimmer" />
                  <div className="h-3 bg-sr-surface-light rounded w-4/5 animate-shimmer" />
                </div>
                <div className="mt-4 flex items-center gap-2 text-xs text-sr-text-muted">
                  <Shield className="h-3 w-3 text-green-400" />
                  Profile data analyzed · Updated 2 days ago
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof / How It Works */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold gradient-text mb-4">Built for the Journey</h2>
            <p className="text-sr-text-muted max-w-xl mx-auto">From grassroots to elite. ScoutRank grows with you at every stage.</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Users, step: '01', title: 'Create Profile', desc: 'Build your athlete identity with sports, stats, and achievements' },
              { icon: TrendingUp, step: '02', title: 'Get Ranked', desc: 'Earn your ScoutRank score and climb the leaderboards' },
              { icon: Medal, step: '03', title: 'Earn Recognition', desc: 'Get verified, build reputation, and attract attention' },
              { icon: Search, step: '04', title: 'Get Discovered', desc: 'Coaches, scouts and clubs find you through your profile' },
            ].map(s => (
              <div key={s.step} className="card-premium p-6 text-center group">
                <div className="text-3xl font-display font-bold text-sr-purple/30 mb-3">{s.step}</div>
                <div className="h-10 w-10 mx-auto rounded-xl bg-gradient-to-br from-sr-purple/20 to-sr-blue/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <s.icon className="h-5 w-5 text-sr-purple-light" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-1.5">{s.title}</h3>
                <p className="text-xs text-sr-text-muted">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4 relative">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-sr-purple/10 to-sr-blue/10 blur-[120px]" />
        </div>
        <div className="relative max-w-2xl mx-auto text-center">
          <Logo size="lg" className="justify-center mb-6" />
          <h2 className="text-3xl sm:text-5xl font-display font-bold gradient-text mb-4">
            Rank, Rise and Repeat
          </h2>
          <p className="text-lg text-sr-text-muted mb-8">
            Join thousands of athletes building their sporting reputation on ScoutRank.
          </p>
          <Button variant="brand" size="lg" onClick={() => navigate('/signup')} icon={<ArrowRight className="h-5 w-5" />}>
            Create Your Profile Now
          </Button>
          <p className="text-xs text-sr-text-muted mt-4">Free to join. Build your reputation today.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-sr-border py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <Logo size="sm" withText={false} />
          <div className="flex items-center gap-6 text-sm text-sr-text-muted">
            <a href="#" className="hover:text-white transition-colors">About</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
          <p className="text-xs text-sr-text-muted">© 2026 ScoutRank. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
