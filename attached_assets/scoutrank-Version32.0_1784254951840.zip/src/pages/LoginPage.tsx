import { useState, type FormEvent } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Logo } from '@/components/ui/Logo';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/contexts/AuthContext';
import { Eye, EyeOff, Mail, Lock } from 'lucide-react';

// Only ever redirect to a same-app relative path (e.g. "/post/abc123")
// after login — never to an absolute URL someone could craft via the
// query string (?redirect=https://evil.example.com) to redirect people
// off-site right after they authenticate.
function safeRedirectPath(value: string | null): string | null {
  if (!value) return null;
  if (!value.startsWith('/') || value.startsWith('//')) return null;
  if (value.includes('://')) return null;
  return value;
}

export default function LoginPage() {
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!email || !password) { setError('Please fill in all fields'); return; }
    try {
      await login(email, password);
      const redirectTo = safeRedirectPath(searchParams.get('redirect'));
      navigate(redirectTo ?? '/dashboard');
    } catch {
      setError('Invalid email or password');
    }
  }

  return (
    <div className="min-h-screen bg-sr-bg flex items-center justify-center p-4 relative">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-sr-purple/8 blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-sr-blue/8 blur-[100px]" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Logo size="lg" className="justify-center mb-3" />
          <p className="text-sr-text-muted text-sm">Welcome back. Log in to your ScoutRank.</p>
        </div>

        {/* Card */}
        <div className="card-premium p-8">
          <h1 className="text-2xl font-bold text-white mb-6">Log In</h1>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-sr-silver mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-sr-text-muted" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="input-dark pl-10"
                  placeholder="alex@email.com"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-sm font-medium text-sr-silver">Password</label>
                <Link to="/forgot-password" className="text-xs text-sr-purple-light hover:text-sr-purple transition-colors">Forgot password?</Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-sr-text-muted" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="input-dark pl-10 pr-10"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-sr-text-muted hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button type="submit" variant="brand" className="w-full" size="lg" loading={isLoading}>
              Log In
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-sr-text-muted">
            Don't have an account?{' '}
            <Link to="/signup" className="text-sr-purple-light hover:text-sr-purple font-medium transition-colors">
              Sign up
            </Link>
          </div>
        </div>

        <p className="text-center text-xs text-sr-text-muted mt-6">
          By logging in, you agree to ScoutRank's{' '}
          <a href="#" className="text-sr-silver hover:text-white">Terms</a> and{' '}
          <a href="#" className="text-sr-silver hover:text-white">Privacy Policy</a>.
        </p>
      </div>
    </div>
  );
}
