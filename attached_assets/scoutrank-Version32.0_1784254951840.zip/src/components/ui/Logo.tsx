interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  withText?: boolean;
  className?: string;
}

// Crops the Spartan warrior icon from the full logo image using CSS
// overflow clipping — the text portion of the PNG is hidden below the
// container boundary. The wordmark and slogan are rendered separately
// so they blend with the dark nav and scale independently.
export function Logo({ size = 'md', withText = false, className = '' }: LogoProps) {
  const containerSize = { sm: 36, md: 44, lg: 64 };
  const px = containerSize[size];

  // Logo PNG is square. Warrior fills top ~65%; text fills bottom ~35%.
  // Setting img height to 154% of container (100/65 ≈ 1.54) and
  // anchoring to top clips exactly at the warrior/text boundary.
  const imgHeight = Math.round(px * 1.54);

  const wordmarkSize = { sm: 'text-base', md: 'text-lg', lg: 'text-2xl' };
  const sloganSize   = { sm: 'text-[8px]', md: 'text-[9px]', lg: 'text-xs' };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* Warrior icon — cropped from top of logo PNG */}
      <div
        className="flex-shrink-0 overflow-hidden"
        style={{ width: px, height: px }}
      >
        <img
          src="/logo.png"
          alt="ScoutRank"
          style={{
            width: px,
            height: imgHeight,
            objectFit: 'cover',
            objectPosition: 'top center',
          }}
          draggable={false}
        />
      </div>

      {withText && (
        <div className="flex flex-col justify-center leading-none">
          <span className={`${wordmarkSize[size]} font-display font-black tracking-wide text-white`}>
            SCOUT<span className="gradient-text-brand">RANK</span>
          </span>
          <span className={`${sloganSize[size]} tracking-widest text-sr-text-muted uppercase mt-0.5`}>
            Rank, Rise and Repeat
          </span>
        </div>
      )}
    </div>
  );
}
