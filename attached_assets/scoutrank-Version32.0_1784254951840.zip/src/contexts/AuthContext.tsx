import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type { Session, User as SupabaseAuthUser } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Profile } from '@/lib/supabase';

// ── Types ──
type Role = 'athlete' | 'coach' | 'scout' | 'parent' | 'admin' | 'super_admin' | null;

interface AuthState {
  user: SupabaseAuthUser | null;
  profile: Profile | null;
  role: Role;
  isLoading: boolean;
  isAuthenticated: boolean;
}

interface AuthContextType extends AuthState {
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (data: SignupData) => Promise<{ needsEmailConfirmation: boolean }>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<Profile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

export interface SignupData {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  dateOfBirth: string;
  country: string;
  state: string;
  city: string;
  primarySport: string;
  secondarySports: string[];
  currentClub: string;
  role: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

const EMPTY_STATE: AuthState = {
  user: null,
  profile: null,
  role: null,
  isLoading: true,
  isAuthenticated: false,
};

// Loads the profile row for a given auth user id. Role lives directly on
// `profiles.role` — confirmed via information_schema; there is no
// separate `users` table (an earlier version of this function assumed
// there was one and queried it, which fails with "Could not find the
// table 'public.users'" since it genuinely doesn't exist).
async function loadProfileAndRole(userId: string): Promise<{ profile: Profile | null; role: Role }> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();

  if (error) {
    console.error('Failed to load profile:', error.message);
  }

  const profile = (data as Profile | null) ?? null;
  return {
    profile,
    role: (profile?.role as Role) ?? null,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(EMPTY_STATE);

  const applySession = useCallback(async (session: Session | null) => {
    if (!session?.user) {
      setState({ ...EMPTY_STATE, isLoading: false });
      return;
    }
    const { profile, role } = await loadProfileAndRole(session.user.id);
    setState({
      user: session.user,
      profile,
      role,
      isLoading: false,
      isAuthenticated: true,
    });
  }, []);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (mounted) applySession(data.session);
    });

    const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      applySession(session);
    });

    return () => {
      mounted = false;
      subscription.subscription.unsubscribe();
    };
  }, [applySession]);

  // ── Login ──
  const login = useCallback(async (email: string, password: string) => {
    setState(s => ({ ...s, isLoading: true }));
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setState(s => ({ ...s, isLoading: false }));
      throw error;
    }
    // onAuthStateChange fires and populates user/profile/role.
  }, []);

  // ── Signup ──
  // The `profiles` row is created server-side by a Postgres trigger on
  // auth.users (see the SQL provided alongside this change) — this function
  // only creates the auth user and passes along metadata for that trigger
  // to consume. It does NOT insert into profiles directly.
  const signup = useCallback(async (data: SignupData) => {
    setState(s => ({ ...s, isLoading: true }));

    const { data: signUpData, error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          username: data.username,
          first_name: data.firstName,
          last_name: data.lastName,
          date_of_birth: data.dateOfBirth,
          country: data.country,
          state: data.state,
          city: data.city,
          primary_sport: data.primarySport,
          secondary_sports: data.secondarySports,
          current_club: data.currentClub,
          role: data.role,
        },
      },
    });

    if (error) {
      setState(s => ({ ...s, isLoading: false }));
      throw error;
    }

    const needsEmailConfirmation = !signUpData.session;
    if (signUpData.session) {
      await applySession(signUpData.session);
    } else {
      // Email confirmation is required by the Supabase project settings.
      // No session yet — the trigger has still run and created the profile,
      // but the person can't log in until they confirm their email.
      setState({ ...EMPTY_STATE, isLoading: false });
    }

    return { needsEmailConfirmation };
  }, [applySession]);

  // ── Logout ──
  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setState({ ...EMPTY_STATE, isLoading: false });
  }, []);

  // ── Refresh profile (e.g. after settings update elsewhere) ──
  const refreshProfile = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session?.user) return;
    const { profile, role } = await loadProfileAndRole(data.session.user.id);
    setState(s => ({ ...s, profile, role }));
  }, []);

  // ── Update profile ──
  const updateProfile = useCallback(async (updates: Partial<Profile>) => {
    if (!state.user) return;
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', state.user.id)
      .select()
      .single();
    if (error) {
      console.error('Failed to update profile:', error.message);
      throw error;
    }
    setState(s => ({ ...s, profile: data as Profile }));
  }, [state.user]);

  const isAdmin = state.role === 'admin' || state.role === 'super_admin';

  return (
    <AuthContext.Provider value={{ ...state, isAdmin, login, signup, logout, updateProfile, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
