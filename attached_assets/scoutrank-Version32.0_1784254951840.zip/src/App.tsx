import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { Layout } from '@/components/layout/Layout';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import VerificationStatusPage from '@/pages/VerificationStatusPage';
import AdminVerificationPage from '@/pages/AdminVerificationPage';
import AdminOrganisationsPage from '@/pages/AdminOrganisationsPage';
import AdminOrganisationRequestsPage from '@/pages/AdminOrganisationRequestsPage';
import OrganisationProfilePage from '@/pages/OrganisationProfilePage';
import ParentDashboardPage from '@/pages/ParentDashboardPage';
import ParentLinkRequestsPage from '@/pages/ParentLinkRequestsPage';
import AdminPendingStatsPage from '@/pages/AdminPendingStatsPage';
import AdminReportsPage from '@/pages/AdminReportsPage';
import SignupPage from '@/pages/SignupPage';
import OnboardingPage from '@/pages/OnboardingPage';
import DashboardPage from '@/pages/DashboardPage';
import AthleteProfilePage from '@/pages/AthleteProfilePage';
import ProfilePage from '@/pages/ProfilePage';
import FeedPage from '@/pages/FeedPage';
import PostDetailPage from '@/pages/PostDetailPage';
import RankingsPage from '@/pages/RankingsPage';
import DiscoverPage from '@/pages/DiscoverPage';
import ClubPage from '@/pages/ClubPage';
import SettingsPage from '@/pages/SettingsPage';
import AdminDashboardPage from '@/pages/AdminDashboardPage';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  if (isLoading) {
    return (
      <div className="min-h-screen bg-sr-bg flex items-center justify-center">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sr-purple to-sr-blue animate-pulse-glow" />
      </div>
    );
  }
  // Carry the page the person was trying to reach (e.g. a shared post
  // link) through to login, as a query param so it survives a refresh
  // on the login page itself, not just React Router's in-memory state.
  if (!isAuthenticated) {
    return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname)}`} />;
  }
  return <ErrorBoundary>{children}</ErrorBoundary>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();
  if (isLoading) {
    return (
      <div className="min-h-screen bg-sr-bg flex items-center justify-center">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sr-purple to-sr-blue animate-pulse-glow" />
      </div>
    );
  }
  if (!isAuthenticated) return <Navigate to="/login" />;
  if (!isAdmin) return <Navigate to="/dashboard" />;
  return <>{children}</>;
}

function ParentRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading, profile } = useAuth();
  if (isLoading) {
    return (
      <div className="min-h-screen bg-sr-bg flex items-center justify-center">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-sr-purple to-sr-blue animate-pulse-glow" />
      </div>
    );
  }
  if (!isAuthenticated) return <Navigate to="/login" />;
  if (profile?.role !== 'parent') return <Navigate to="/dashboard" />;
  return <>{children}</>;
}

function AppRoutes() {
  const { isAuthenticated, isAdmin, profile } = useAuth();

  // Applies the saved theme preference to <html> — see the THEME
  // OVERRIDES block in index.css for what each class actually changes.
  // Defaults to the standard dark theme (no class) when logged out or
  // no preference is set yet.
  useEffect(() => {
    document.documentElement.classList.remove('theme-ultra-dark');
    if (profile?.theme_preference === 'ultra_dark') {
      document.documentElement.classList.add('theme-ultra-dark');
    }
  }, [profile?.theme_preference]);

  const authenticatedDest = isAdmin
    ? '/admin'
    : profile?.role === 'parent'
    ? '/parent'
    : profile?.onboarding_completed === false
    ? '/onboarding'
    : '/dashboard';

  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={isAuthenticated ? (
        <Navigate to={authenticatedDest} />
      ) : <LandingPage />} />
      <Route path="/login" element={isAuthenticated ? (
        <Navigate to={authenticatedDest} />
      ) : <LoginPage />} />
      <Route path="/signup" element={isAuthenticated ? (
        <Navigate to={authenticatedDest} />
      ) : <SignupPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />

      {/* Onboarding — no redirect here; this IS the destination */}
      <Route path="/onboarding" element={<ProtectedRoute><OnboardingPage /></ProtectedRoute>} />
      <Route path="/verification-status" element={<ProtectedRoute><VerificationStatusPage /></ProtectedRoute>} />
      {/* Parent routes */}
      <Route path="/parent" element={<ParentRoute><ParentDashboardPage /></ParentRoute>} />
      <Route path="/parent/link-requests" element={<ProtectedRoute><ParentLinkRequestsPage /></ProtectedRoute>} />

      {/* Admin route - protected with role check */}
      <Route path="/admin" element={<AdminRoute><AdminDashboardPage /></AdminRoute>} />
      <Route path="/admin/verification" element={<AdminRoute><AdminVerificationPage /></AdminRoute>} />
      <Route path="/admin/organisations" element={<AdminRoute><AdminOrganisationsPage /></AdminRoute>} />
      <Route path="/admin/organisation-requests" element={<AdminRoute><AdminOrganisationRequestsPage /></AdminRoute>} />
      <Route path="/admin/pending-stats" element={<AdminRoute><AdminPendingStatsPage /></AdminRoute>} />
      <Route path="/admin/reports" element={<AdminRoute><AdminReportsPage /></AdminRoute>} />

      {/* Layout routes for normal users */}
      <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/feed" element={<FeedPage />} />
        <Route path="/post/:id" element={<PostDetailPage />} />
        <Route path="/rankings" element={<RankingsPage />} />
        <Route path="/discover" element={<DiscoverPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/profile/:username" element={<ProfilePage />} />
        <Route path="/organisation/:id" element={<OrganisationProfilePage />} />
        <Route path="/club/:slug" element={<ClubPage />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={
        <div className="min-h-screen bg-sr-bg flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-6xl font-display font-bold gradient-text mb-4">404</h1>
            <p className="text-sr-text-muted">Page not found</p>
          </div>
        </div>
      } />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
